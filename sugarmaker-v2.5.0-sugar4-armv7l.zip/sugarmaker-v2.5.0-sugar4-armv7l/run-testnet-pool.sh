./sugarmaker -a YespowerSugar -o stratum+tcp://1pool-testnet.cryptozeny.com:3333 -u tugar1qkvl32hmzvgtwpu7v70k5u0kcv9s4uqy4twjge8 -t1
